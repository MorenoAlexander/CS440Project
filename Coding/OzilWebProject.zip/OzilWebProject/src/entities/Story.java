package entities;

public class Story extends Scenario {

	public Story(String title, String description, String priority, int storyID) {
		this.title = title;
		this.description = description;
		this.ID = storyID;
	}
	
	
}
