package entities;

public class Task extends Scenario{
	
	private String priority;
	private int storyID;
	
	public String getPriority() {
		return priority;
	}
	
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public Task(String taskName, String descrptn, int taskID, String priorty, int storyId){
		title = taskName;
		description = descrptn; 
		ID = taskID;
		priority = priorty;
		storyID = storyId;
	}
	
	public int getStoryID() {
		return storyID;
	}

	public void setStoryID(int storyID) {
		this.storyID = storyID;
	}

	public void editPriority(String newPriority) {
		setPriority(newPriority);
	}
	

}
