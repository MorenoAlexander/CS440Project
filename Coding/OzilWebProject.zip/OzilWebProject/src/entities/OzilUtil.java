package entities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class OzilUtil {
	private static User currentUser;
	static ArrayList<String> Ts = new ArrayList<String>();


	private static SQLManager dbInterface;


	private static void setdb()
	{
		Ts.add("CREATE TABLE users(userId integer,fName varchar(60),lName varchar(60),email varchar(60),userName varchar(60),password varchar(64),primary key(userId));");
		Ts.add("CREATE TABLE projects(projectId INTEGER, projectTitle VARCHAR(60),data BLOB, PRIMARY KEY(projectId); ");
		Ts.add("CREATE TABLE user_projects("
				+ "index INTEGER,"
				+ "userId INTEGER NOT NULL,"
				+ "projectId INTEGER NOT NULL"
				+ "PRIMARY KEY(index),"
				+ "FOREIGN KEY(userId) REFERENCES users(userId),"
				+ "FOREIGN KEY(projectId) REFERENCES projects(projectID));");
		
		Ts.add("CREATE TABLE story(storyId integer, title varchar(60),description varchar(100),primary key(storyId));");
		Ts.add("CREATE TABLE task(taskId integer, storyId integer, title varchar(60),description varchar(100),priority varchar(20),primary key(taskId), FOREIGN KEY(storyId) REFERENCES story(storyId));");

		dbInterface = new SQLManager("OzilUsersDB.db",
				"SELECT name FROM sqlite_master WHERE type='table' AND name='users'",Ts);
	}


	/*
	 * Initialize an empty data base
	 */



	/**
	 * Addes a new user to the database
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private static int  addUser(String firstName, String lastName, String email,String username,String passwrd) throws ClassNotFoundException, SQLException
	{
		if(SQLManager.getCon() == null)
		{
			return -1;
		}

		PreparedStatement prep = SQLManager.preparedStatement("INSERT INTO users values(?, ?, ?, ?, ?, ?);");
		prep.setString(2, firstName);
		prep.setString(3, lastName);
		prep.setString(4, email);
		prep.setString(5, username);
		prep.setString(6, passwrd);
		prep.execute();


		Connection conn = dbInterface.getCon();
		Statement stmt = conn.createStatement();
		ResultSet id  = stmt.executeQuery("SELECT userId FROM users WHERE fName ='"+ firstName + "'AND lName = '"+lastName+"' AND email='"+email+ "' AND userName='"+username+ "';");
		//sql query to return user ID

		if(id.next())
			return id.getInt(1);

		else
			return -1;
	}


	/***
	 * Check for valid email format
	 */
	public static boolean validateEmail(String emailstr)
	{
		//email regex
		Pattern pat = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\."+ "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
				"A-Z]{2,7}$");


		if(emailstr == null)
		{
			return false;
		}


		return pat.matcher(emailstr).matches();
	}




	/**
	 * 
	 * 
	 * Returns: a user object for the new user, or null for exit
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public static boolean signIn(String username,String paswd) throws ClassNotFoundException, SQLException
	{

		//get username and password
		//if corresponding username and password exist in database, create a user object for that

		//sqlmanager.executeQuery();

		Connection conn = dbInterface.getCon();
		Statement stmt = conn.createStatement();
		ResultSet set = stmt.executeQuery("SELECT password,fName,lName,email,userId FROM users WHERE username= '"+ username + "'; ");
		if(set.next()) 
		{
			if(set.getString(1).isEmpty() == true)
				return false;
			else if(set.getString(1).equals(paswd))
			{
				currentUser = new User(set.getString(2),set.getString(3),set.getString(4),username,paswd);
				currentUser.setUserID(Integer.parseInt(set.getString(5)));
				return true;
			}


		}

		return false;
	}

	public static boolean signUp(String fName,String lName,String email,String username,String paswd) throws ClassNotFoundException, SQLException
	{


		//email validation

		if(!validateEmail(email))
		{
			return false;
		}

		int userid = addUser(fName,lName,email,username,paswd); //add the user to the database
		currentUser = new User(fName,lName,email,username,paswd);
		currentUser.setUserID(userid);

		return true;


	}


	public static void initProject() throws ClassNotFoundException, SQLException {
		//TODO set up command line loop
		currentUser =  null;

		setdb();
		//

		//connect to database
		if(SQLManager.getCon() == null)
		{
			SQLManager.getCon();
		}


	}
}




















